/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sir.daniyal;

import java.util.Scanner;

/**
 *
 * @author M SHIRAZ
 */
public class Q8 {
 
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        
         String alphabet;       
        System.out.print("enter the alphabet = ");
        alphabet= sc.next();
        if(alphabet.length()==1){
            switch (alphabet) {
                case "a":
                case "A":
                case "e":
                case "E": 
                case "i":
                case "I":
                case "o":
                case "O":
                case "u":
                case "U":
                    System.out.println(alphabet+" is a vowel");
                    break;
                default:
                    System.out.println(alphabet+" is a consonant");
            }
        }
        else{
            System.out.println("error enter only 1 alphabet");
        }
    }
}
