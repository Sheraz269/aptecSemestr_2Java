/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sir.daniyal;

import java.util.Scanner;

/**
 *
 * @author M SHIRAZ
 */
public class Q1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
     
        
       int x;
        System.out.print("enter any integer number = ");
        x = sc.nextInt();
        if(x>=0){ 
            System.out.println(x + " is positive");
        }
        else{
            System.out.println(x + " is negative");
        }
    
    
    }
    
}
