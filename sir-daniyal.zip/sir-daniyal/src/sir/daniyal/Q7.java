/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sir.daniyal;

import java.util.Scanner;

/**
 *
 * @author M SHIRAZ
 */
public class Q7 {
 
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        
        int month;
        int year;
        System.out.print("enter the number of month = ");
        month = sc.nextInt();
        System.out.print("enter the year = ");
        year = sc.nextInt();
        
        if (month== 2 && year%4==0) {
            System.out.println("february "+year+" has"+" 29 days");
        }
        else{
            switch (month) {
                case 1:
                    System.out.println("januray "+year+" has 31 days");
                    break;
                case 2:
                    System.out.println("february "+year+" has 28 days");
                    break; 
                case 3:
                    System.out.println("march "+year+" has 31 days");
                    break;
                case 4:
                    System.out.println("april "+year+" has 30 days");
                    break;
                case 5:
                    System.out.println("may "+year+" has 31 days");
                    break;
                case 6:
                    System.out.println("june "+year+" has 30 days");
                    break;
                case 7:
                    System.out.println("july "+year+" has 31 days");
                    break; 
                case 8:
                    System.out.println("august "+year+" has 31 days");
                    break;
                case 9:
                    System.out.println("september "+year+" has 30 days");
                    break;
                case 10:
                    System.out.println("octuber "+year+" has 31 days");
                    break;
                case 11:
                    System.out.println("november "+year+" has 30 days");
                    break;
                case 12:
                    System.out.println("december "+year+" has 31 days");
                    break;
                default:
                    System.out.println("something is wrong");
            }
        }
        
        
    }
}
