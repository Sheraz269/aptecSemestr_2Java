/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sir.daniyal;

import java.util.Scanner;

/**
 *
 * @author M SHIRAZ
 */
public class Q6 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
         double num1,num2; 
 
        System.out.print("enter first floating­point number = "); 
        num1 = sc.nextDouble(); 
        System.out.print("enter second floating­point number = "); 
        num2 = sc.nextDouble();
  
        if (Math.abs(num1 - num2) <= 0.01) { 
            System.out.println("These numbers are the same."); 
        } 
        else { 
            System.out.println("These numbers are different."); 
        } 
    }
}
