/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sir.daniyal;

import java.util.Scanner;

/**
 *
 * @author M SHIRAZ
 */
public class Q5 {
    
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        
         int week;
        System.out.print("Enter date to get weekday = ");
        week = sc.nextInt();
        if(week>7){
            week= week/7;
        switch(week){
            case 1:
                System.out.println("Monday");
                break;        
            case 2:
                System.out.println("tuesday");
                break;               
            case 3:
                System.out.println("wednesday");
                break;               
            case 4:
                System.out.println("thursday");
                break;               
            case 5:
                System.out.println("friday");
                break;                
            case 6:
                System.out.println("saturday");
                break;                
            case 7:
                System.out.println("chutti / sunday");
                break;            
            default:
                System.out.println("wrong input");        
        }      
        }
        else{        
         switch(week){
            case 1:
                System.out.println("Monday");
                break;                
            case 2:
                System.out.println("tuesday");
                break;               
            case 3:
                System.out.println("wednesday");
                break;              
            case 4:
                System.out.println("thursday");
                break;               
            case 5:
                System.out.println("friday");
                break;               
            case 6:
                System.out.println("saturday");
                break;                
            case 7:
                System.out.println("chutti / sunday");
                break;            
            default:
                System.out.println("wrong input");        
        }      
        }
    }
}
