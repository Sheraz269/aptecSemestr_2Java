/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sir.daniyal;

import java.util.Scanner;

/**
 *
 * @author M SHIRAZ
 */
public class Q2 {
    
    public static void main(String[] args) {
        
         
        int value1, value2, value3;
        double root1, root2, x;
        Scanner sc = new Scanner(System.in);
        System.out.println("Given quadratic equation = ax^2 + bx + c");
        System.out.print("Enter value1 = ");
        value1 = sc.nextInt();
        System.out.print("Enter value2 = ");
        value2 = sc.nextInt();
        System.out.print("Enter value3 = ");
        value3 = sc.nextInt();
        System.out.println("Given quadratic equation = "+value1+"x^2 + "+value2+"x + "+value3);
        x = value2 * value2 - 4 * value1 * value3;
        if(x > 0)
        {
            System.out.println("Roots are real and unequal");
            root1 = ( - value2 + Math.sqrt(x))/(2*value1);
            root2 = (-value2 - Math.sqrt(x))/(2*value1);
            System.out.println("First root is = "+root1);
            System.out.println("Second root is = "+root2);
        }
        else if(x == 0)
        {
            System.out.println("Roots are real and equal");
            root1 = (-value2+Math.sqrt(x))/(2*value1);
            System.out.println("Root:"+root1);
        }
        else
        {
            System.out.println("Roots are imaginary");
        }

    }
}
