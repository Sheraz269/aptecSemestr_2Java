/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sir.daniyal;

import java.util.Scanner;

/**
 *
 * @author M SHIRAZ
 */
public class Q9 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int Year;        
        System.out.print("enter the year = ");
        Year = sc.nextInt();
        if (Year%4==0) {
            System.out.println(Year+" is a leap year");
        }else{
            System.out.println(Year+" is not a leap year");
        }
        
        
        
    
    }
}
