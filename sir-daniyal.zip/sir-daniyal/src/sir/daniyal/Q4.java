/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sir.daniyal;

import java.util.Scanner;

/**
 *
 * @author M SHIRAZ
 */
public class Q4 {
  
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
          double floatingPoint;
        
        System.out.print("enter the float value = ");
        floatingPoint = sc.nextDouble();
        
        if (floatingPoint==0) {
            System.out.println("zero");
        }
        else if (floatingPoint<0) {
            System.out.println("nagetive number");
        } 
        else if (floatingPoint>0 && floatingPoint<1) {
            System.out.println("small , positive number");
        }
        else if (floatingPoint>1000000) {
            System.out.println("large , positive number");
        }else{
            System.out.println("positive number");
        }
        
    }
}
