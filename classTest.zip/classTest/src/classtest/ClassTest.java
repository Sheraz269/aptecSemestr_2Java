/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classtest;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ClassTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
////        //1  
////        int x;
////        
////        x = sc.nextInt();
////        
////        if(x>=0){
////        
////            System.out.println(x + " positive ");
////        }
////        else{
////            System.out.println(x + " negative");
////        }
////    
////        //2
            
//            int a, b, c;
//            double root1, root2, d;
//            Scanner s = new Scanner(System.in);
//            System.out.println("Given quadratic equation:ax^2 + bx + c");
//            System.out.print("Enter a:");
//            a = s.nextInt();
//            System.out.print("Enter b:");
//            b = s.nextInt();
//            System.out.print("Enter c:");
//            c = s.nextInt();
//            System.out.println("Given quadratic equation:"+a+"x^2 + "+b+"x + "+c);
//            d = b * b - 4 * a * c;
//            if(d > 0)
//            {
//                System.out.println("Roots are real and unequal");
//                root1 = ( - b + Math.sqrt(d))/(2*a);
//                root2 = (-b - Math.sqrt(d))/(2*a);
//                System.out.println("First root is:"+root1);
//                System.out.println("Second root is:"+root2);
//            }
//            else if(d == 0)
//            {
//                System.out.println("Roots are real and equal");
//                root1 = (-b+Math.sqrt(d))/(2*a);
//                System.out.println("Root:"+root1);
//            }
//            else
//            {
//                System.out.println("Roots are imaginary");
//            }
        
        
        
        
////        //3
////        System.out.println("");
////        
////        int a,b,c;
////        System.out.println("Enter number");
////        a= sc.nextInt();
////        System.out.println("Enter number");
////        b= sc.nextInt();
////        System.out.println("Enter number");
////        c= sc.nextInt();
////        
////        if(a>b && a>c){
////            System.out.println(a + " this is the greater");
////        }
////        else if(b>a && b>c){
////           System.out.println(b + " this is the greater");
////        }
////        
////        else if(c>a && c>b){
////           System.out.println(c + " this is the greater");
////        }
////        
        
       //4
        
//        float z;
//        z = sc.nextFloat();
//        
//        if(z){}
        
        
       

//        //5
//        
//        int w;
//        System.out.print("Enter positive number te get weekday = ");
//        w = sc.nextInt();
//        if(w>7){
//            w= w/7;
//        switch(w){
//            case 1:
//                System.out.println("Monday");
//                break;
//                
//            case 2:
//                System.out.println("tuesday");
//                break;
//                
//            case 3:
//                System.out.println("wednesday");
//                break;
//                
//            case 4:
//                System.out.println("thursday");
//                break;
//                
//            case 5:
//                System.out.println("friday");
//                break;
//                
//            case 6:
//                System.out.println("saturday");
//                break;
//                
//            case 7:
//                System.out.println("chutti / sunday");
//                break;
//                
//            
//            default:
//                System.out.println("wrong input");
//        
//        }
//        
//        }
//        else{
//        
//         switch(w){
//            case 1:
//                System.out.println("Monday");
//                break;
//                
//            case 2:
//                System.out.println("tuesday");
//                break;
//                
//            case 3:
//                System.out.println("wednesday");
//                break;
//                
//            case 4:
//                System.out.println("thursday");
//                break;
//                
//            case 5:
//                System.out.println("friday");
//                break;
//                
//            case 6:
//                System.out.println("saturday");
//                break;
//                
//            case 7:
//                System.out.println("chutti / sunday");
//                break;
//                
//            
//            default:
//                System.out.println("wrong input");
//        
//        }
//        
//      
//        }
        
        
        int month;
        int year;
        
        month = sc.nextInt();
        year = sc.nextInt();
        
        switch(month){
        
            case 2:
                System.out.println("28");
                break;
        }
        month = month / 2;
        
        
        if (month==1) {
            
            System.out.println("30");
            
        }
        else{
        
            System.out.println("31");
        }
    
    }
    
}
