/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package foocorporation;

/**
 *
 * @author user
 */
public class FooCorporation { // made class of FooCorporation 
 
    public void totalPay(double basePay, double hours ){ // method that calculates total salary.
       double totalPay; // declare name of variable.
       
        if(hours<=40 && basePay>=8){ // using if condition
            totalPay = basePay * hours; // doing calculation as per giving condition.
            System.out.println("Total Salary is = " + totalPay + "$" );
        }else if (hours > 60) {
            System.out.println("Hours should not be exceed more than 60");
        }
        else if (hours > 40 && basePay>=8) {
            basePay = basePay * 1.5;    
            totalPay = basePay * hours;
            System.out.println("Total Salary is = " + totalPay + "$" );
        }
        else {
            System.out.println("Base Pay should not be less than 8$ "); 
        }
 
    }
    
    
}
