/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package foocorporation;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        FooCorporation obj = new FooCorporation();// making an object of class FooCorporation
        Scanner sc = new Scanner(System.in); // use scanner for input
        double a,b;
       
        for(int i=1; i<=3; i++){
            System.out.println("Enter values for Employee" + i);
            a = sc.nextDouble();
            b = sc.nextDouble();
            System.out.println("Employee" + i );
            obj.totalPay(a , b);
            System.out.println();
        }
    
    }
    
}
