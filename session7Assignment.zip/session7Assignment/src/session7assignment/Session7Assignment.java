/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session7assignment;

import java.util.Scanner;

/**
 *
 * @author Muhammad Shiraz
 */
public class Session7Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner cs = new Scanner(System.in);
       login log = new login();
       
        System.out.print("Enter user name = ");
       String name = cs.next();
       
        System.out.print("Enter Password = ");
       int pass = cs.nextInt();
    log.setDesignation("Employe");
    log.setName(name);
    log.setPassword(pass);
    
    
    
        System.out.println("Designation = " + log.getDesig());
        System.out.println( "Name = "  + log.getName());
        System.out.println( "Password = " + log.getPassword());
    
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        System.out.print("Enter user name = ");
        String name1 = cs.next();
        System.out.print("Enter Password = ");
       int pass1 = cs.nextInt();

    log.validate(name1 ,pass1 );    
        
    
    
    }
    
}
