/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session7assignment;

/**
 *
 * @author Muhammad Shiraz
 */
public class login {
/**
 * in this class we use access and mutator
 * 
 * 
 */
    
   private String userName, designation;
   private int password;
   
   /**
    * @param name
    * 
    */
   
   void setName(String name){
       userName = name;
   }
   void setDesignation(String desig){
       designation = desig;
   }
   
   void setPassword(int pass){
       password = pass;
   
   }
   
   
   String getName(){
        
        return userName;
   
     }
   String getDesig(){
       
       return designation;
   
     }
   
   int getPassword(){
     return password;
   }
   
   
   
   void validate(String Name, int pass){
   
       if("syed".equals(Name)){
           
           if(pass == 123){
           
               System.out.println("Welcome");
           }else{
               System.out.println("wrong Password");
           }
       }else{
           System.out.println("wrong name");
       }
   }    
   
   

   
}
