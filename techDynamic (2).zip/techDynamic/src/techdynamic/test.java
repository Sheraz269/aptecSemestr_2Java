/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techdynamic;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("name");
        String n =sc.next();
        
        System.out.println("pass");
        String p =sc.next();
        
        
        login obj = new login();
       
        obj.addUser("www", "123", "CEo");
        
        System.out.println("want to uppdate");
        
        System.out.println("name");
        String updaten =sc.next();
        
        System.out.println("pass");
        String updatep =sc.next();
        
       obj.get(updaten, updatep);
        obj.validate(n, p);
         
//           obj.get("admin2", "123");
//           obj.validate("", "1234");
    }
    
}
