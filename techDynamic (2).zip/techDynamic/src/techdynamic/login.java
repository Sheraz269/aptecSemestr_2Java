/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techdynamic;

/**
 *
 * @author Student
 */
public class login {
    
   private String username ;
   private String password;
   private String designation;
   
   
   public void addUser(String u,String p,String d){
   
       username = u ; 
       password = p ;
       designation = d;
       
   }
   
   void get(String a,String b){ // this method is for overriding
   
       username = a;
       password = b;
   
   }
   
   public void validate(String user,String pass){
   
       if(user.equals(username) && pass.equals(password)){
       
           System.err.println("Welcome " + user);
       }
       else{
            System.err.println("Invalid");
       }
   }
}
