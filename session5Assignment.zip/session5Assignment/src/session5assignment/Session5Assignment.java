/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session5assignment;

import java.util.Scanner;

/**
 *
 * @author Muhammad Shiraz
 */
public class Session5Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        
        System.out.print("The university is introducing the IQ testing system for its students ");
        System.out.println("The IQ test will test the students on four different kind of following subjects : ");
        System.out.println(" 1- Aptitude \n 2- English \n 3- Mathematics \n 4- Gernel Knowledge ");
        System.out.println(" This test is only for those who have'nt taken this test before ");
        System.out.println(" Press 1 for taking this test first time \n press any number except 1 who have taken this test before ");
        
        int numberOfAttempt , wichSubject, exit, bonus ;
        int point = 0; 
        String questions;
        numberOfAttempt = input.nextInt();
        if(numberOfAttempt == 1 ){
            System.out.println("For the first time can only choose 1 subject");
            System.out.println(" Press 1 for Aptitude \n Press 2 for English \n Press 3 for Mathematics \n Press 4 for GK Press ");
            System.out.println("After attempting the questions you can Exit the program by pressing 5");
            wichSubject = input.nextInt();
            
            switch(wichSubject){
                
                case 1:
                    //1st question
                    System.out.println("You have chosen Aptitude");
                    System.out.println("Q1. A sum of money at simple interest amounts to Rs. 815 in 3 years and to Rs. 854 in 4 years. The sum is:");
                    System.out.println(" A. Rs. 650 \n B. Rs. 690 \n C. Rs. 698 \n D. Rs. 700");
                    questions = input.next();
                        if("a".equals(questions) || "A".equals(questions) ){
                            System.out.println(" wrong answer");
                            System.out.println("");
                        }
                        else if("b".equals(questions) || "B".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");

                        }
                         else if("c".equals(questions) || "C".equals(questions)){
                            System.out.println("right answer");
                            point = point + 10;
                            System.out.println("you get " + point  +" points");
                            System.out.println("");

                            
                        }
                         else if("d".equals(questions) || "D".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");

                         }
                        // 1st question end
                        //2nd question
                        
                       
                    System.out.println("Q2. Mr. Thomas invested an amount of Rs. 13,900 divided in two different schemes A and B at the simple interest rate of 14% p.a. and 11% p.a. \n respectively. If the total amount of simple interest earned in 2 years be Rs. \n 3508, what was the amount invested in Scheme B?");
                    System.out.println(" A. Rs. 6400 \n B. Rs. 6500 \n C. Rs. 6500 \n D. Rs. 7500");
                    questions = input.next();
                        if("a".equals(questions) || "A".equals(questions) ){
                            System.out.println("right answer");
                            point = point + 10;
                            System.out.println("you get " + point  +" points");
                            System.out.println("");

                        }
                        else if("b".equals(questions) || "B".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");

                        }
                         else if("c".equals(questions) || "C".equals(questions)){
                              System.out.println(" wrong answer");
                              System.out.println("");
 
                        }
                         else if("d".equals(questions) || "D".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");
                        }
                        
                        //q2 ends
                        
                        //question3 starts
                        
                    System.out.println("Q3. How much time will it take \n for an amount of Rs. 450 to yield Rs. 81 as interest at 4.5% per annum \n of simple interest?");
                    System.out.println(" A. 3.5 years \n B. 4 years \n 4.5 years \n D. 5 years");
                    questions = input.next();
                        if("a".equals(questions) || "A".equals(questions) ){
                           System.out.println("wrong answer");
                            System.out.println("");

                        }
                        else if("b".equals(questions) || "B".equals(questions)){
                            
                            System.out.println("right answer");
                            point = point + 10;
                            System.out.println("you get " + point  +" points");
                            System.out.println("");

                        }
                         else if("c".equals(questions) || "C".equals(questions)){
                              System.out.println(" wrong answer");
                              System.out.println("");
 
                        }
                         else if("d".equals(questions) || "D".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");
                        }
                        
                        //q3 end
                        
                    // Question 4 starst
                    System.out.println("Q4. A sum of Rs. 12,500 amounts to Rs. 15,500 in 4 years at the rate of simple interest. \n What is the rate of interest?");
                    System.out.println(" A. 3% \n B. 4% \n C. 5% \n D. 6%");
                    questions = input.next();
                        if("a".equals(questions) || "A".equals(questions) ){
                           System.out.println("wrong answer");
                           System.out.println("");

                        }
                        else if("b".equals(questions) || "B".equals(questions)){
                            
                           System.out.println("wrong answer");
                           System.out.println("");

                        }
                         else if("c".equals(questions) || "C".equals(questions)){
                              System.out.println(" wrong answer");
                              System.out.println("");
 
                        }
                         else if("d".equals(questions) || "D".equals(questions)){
                             System.out.println("right answer");
                            point = point + 10;
                             System.out.println("you get " + point  +" points");
                             System.out.println("");
                            }
                                 System.err.println("press 5 for exit ");
                                 exit = input.nextInt();
                                 if(exit == 5){
                                     System.out.println("your total score = " + point);
                                 switch(point){
                                     case 10:
                                       bonus = point + 0;
                                         System.out.println("You earn no points \n your score shall remain same ");
                                         System.out.println("YOur IQ level is below average");
                                    break;
                                         
                                     case 20:
                                         bonus = point + 2;
                                         System.out.println("You earn 2 points in bonus");
                                         System.out.println("Your IQ level is average");
                                     break;
                                     
                                     case 30:
                                         bonus = point + 5;
                                         System.out.println("You earn 5 points in bonus");
                                         System.out.println("You are intelligent");
                                     break;
                                             
                                 
                                     
                                 }
                                     
                                System.exit(0);
                                 }
                        
                    // q4 end 
                                 
                    break;
            
            }
            
            
            
            
        }else {
            System.out.println("you cannot attempt this test");
        }
        
        
        
    
    }
    
}
