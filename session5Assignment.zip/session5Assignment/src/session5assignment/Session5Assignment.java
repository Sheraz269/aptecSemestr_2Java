/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session5assignment;

import java.util.Scanner;

/**
 *
 * @author Muhammad Shiraz
 */
public class Session5Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        
        System.out.print("The university is introducing the IQ testing system for its students ");
        System.out.println("The IQ test will test the students on four different kind of following subjects : ");
        System.out.println(" 1- Aptitude \n 2- English \n 3- Mathematics \n 4- Gernel Knowledge ");
        System.out.println(" This test is only for those who have'nt taken this test before ");
        System.out.println(" Press 1 for taking this test first time \n press any number except 1 who have taken this test before ");
        
        int numberOfAttempt , howManySubject, exit;
        int poin1, point2, point3, point4, ponit5, netPoint; //store answer in each point & netPoint is the sum of all points.
        String questions;
        numberOfAttempt = input.nextInt();
        if(numberOfAttempt == 1 ){
            System.out.println("For the first time can only choose 1 subject");
            System.out.println(" Press 1 for Aptitude \n Press 2 for English \n Press 3 for Mathematics \n Press 4 for GK Press ");
            System.out.println("After attempting the questions you can Exit the program by pressing 5");
            howManySubject = input.nextInt();
            
            switch(howManySubject){
                
                case 1:
                    //1st question
                    System.out.println("You have chosen Aptitude");
                    System.out.println("Q1. A sum of money at simple interest amounts to Rs. 815 in 3 years and to Rs. 854 in 4 years. The sum is:");
                    System.out.println(" A. Rs. 650 \n B. Rs. 690 \n C. Rs. 698 \n D. Rs. 700");
                    questions = input.next();
                        if("a".equals(questions) || "A".equals(questions) ){
                            System.out.println(" wrong answer");
                            System.out.println("");
                        }
                        else if("b".equals(questions) || "B".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");

                        }
                         else if("c".equals(questions) || "C".equals(questions)){
                            System.out.println("right answer");
                            poin1 = 10;
                            System.out.println("you get 10 points ");
                            System.out.println("");

                            
                        }
                         else if("d".equals(questions) || "D".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");

                         }
                        // 1st question end
                        //2nd question
                        
                       
                    System.out.println("Q2. Mr. Thomas invested an amount of Rs. 13,900 divided in two different schemes A and B at the simple interest rate of 14% p.a. and 11% p.a. \n respectively. If the total amount of simple interest earned in 2 years be Rs. \n 3508, what was the amount invested in Scheme B?");
                    System.out.println(" A. Rs. 6400 \n B. Rs. 6500 \n C. Rs. 6500 \n D. Rs. 7500");
                    questions = input.next();
                        if("a".equals(questions) || "A".equals(questions) ){
                            System.out.println("right answer");
                            point2 = 10;
                            System.out.println("you get 10 points ");
                            System.out.println("");

                        }
                        else if("b".equals(questions) || "B".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");

                        }
                         else if("c".equals(questions) || "C".equals(questions)){
                              System.out.println(" wrong answer");
                              System.out.println("");
 
                        }
                         else if("d".equals(questions) || "D".equals(questions)){
                            System.out.println("wrong answer");
                            System.out.println("");
                        }
                        
                        //q2 ends
                        
                    // 3 questions left 
                    
                    break;
            
            }
            
            
            
            
        }
        
        
        else {
            System.out.println("you cannot attempt this test");
        }
    
    }
    
}
