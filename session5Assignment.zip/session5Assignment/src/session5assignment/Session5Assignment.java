/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session5assignment;

import java.util.Scanner;

/**
 *
 * @author Muhammad Shiraz
 */
public class Session5Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        
        System.out.print("The university is introducing the IQ testing system fro its students ");
        System.out.println("The IQ test will test the students on four different kind of following subjects : ");
        System.out.println(" 1- Aptitude \n 2- English \n 3- Mathematics \n 4- Gernel Knowledge ");
        System.out.println("Those students can choose multiple test subjects who have taken this test before  ");
        System.out.println("But for those who are taking this test for the first time can only choose 1 subject. ");
        System.out.println(" Press 1 for taking this test first time \n press 2 who have taken this test before ");
        
        int numberOfAttempt , howManySubject;
        int poin1, point2, point3, point4, ponit5, netPoint; //store answer in each point & netPoint is the sum of all points.
        String questions;
        numberOfAttempt = input.nextInt();
        if(numberOfAttempt == 1 ){
            System.out.println("For the first time can only choose 1 subject");
            System.out.println(" Press 1 for Aptitude \n Press 2 for English \n Press 3 for Mathematics \n Press 4 for GK Press ");
            System.out.println("After attempting the questions you can Exit the program by pressing 5");
            howManySubject = input.nextInt();
            
            switch(howManySubject){
                
                case 1:
                    System.out.println("You have chosen Aptitude");
                    System.out.println("Q1. A sum of money at simple interest amounts to Rs. 815 in 3 years and to Rs. 854 in 4 years. The sum is:");
                    System.out.println(" A. Rs. 650 \n B. Rs. 690 \n C. Rs. 698 \n D. Rs. 700");
                    questions = input.next();
                        if("a".equals(questions) || "A".equals(questions) ){
                            System.out.println(" wrong answer");
                        }
                        else if("b".equals(questions) || "B".equals(questions)){
                            System.out.println("wrong answer");
                        }
                         else if("c".equals(questions) || "C".equals(questions)){
                            System.out.println("right answer");
                            poin1 = 10;
                            System.out.println("you get 10 points ");
                            
                        }
                         else if("d".equals(questions) || "D".equals(questions)){
                            System.out.println("wrong answer");
                        }
                    // 4 questions left 
                    
                    break;
            
            }
            
            
            
            
        }
        
        else if(numberOfAttempt == 2){
            System.out.println("YOu can chose multiple test"); 
        }
        
        else {
            System.out.println("invalid input");
        }
    
    }
    
}
