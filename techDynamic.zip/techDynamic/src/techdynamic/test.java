/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techdynamic;

/**
 *
 * @author Student
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        login obj = new login();
        obj.addUser("admin", "123", "manager");
        obj.addUser("admin1", "123", "manager");
        obj.validate("admin1", "123");
    }
    
}
