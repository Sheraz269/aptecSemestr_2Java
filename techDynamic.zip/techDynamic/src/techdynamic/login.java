/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techdynamic;

/**
 *
 * @author Student
 */
public class login {
    
   public String username=null ;
   public String password;
   public String designation;
   
   
   public void addUser(String u,String p,String d){
   
       username = u;
       password = p;
       designation = d;
       
   }
   
   public void validate(String user,String pass){
   
       if(user.equals(username) && pass.equals(password)){
       
           System.err.println("Welcome " + user);
       }
       else{
            System.err.println("Invalid");
       }
   }
}
